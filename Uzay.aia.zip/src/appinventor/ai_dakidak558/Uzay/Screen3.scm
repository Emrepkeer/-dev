#|
$JSON
{"authURL":[],"YaVersion":"233","Source":"Form","Properties":{"$Name":"Screen3","$Type":"Form","$Version":"31","Uuid":"0","Title":"Screen3","AppName":"Uzay"}}
|#