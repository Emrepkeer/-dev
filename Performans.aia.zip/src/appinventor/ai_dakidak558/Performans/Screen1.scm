#|
$JSON
{"authURL":["ai2a.appinventor.mit.edu"],"YaVersion":"233","Source":"Form","Properties":{"$Name":"Screen1","$Type":"Form","$Version":"31","ActionBar":"True","AlignHorizontal":"3","AlignVertical":"3","AppName":"Performans","BackgroundImage":"AnaEkran.png","Title":"Screen1","Uuid":"0","$Components":[{"$Name":"Button1","$Type":"Button","$Version":"7","BackgroundColor":"&HFFE16B6B","Text":"Ba\u015flamak \u0130\u00e7in Dokunun","Uuid":"2147067573"}]}}
|#